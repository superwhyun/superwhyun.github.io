# DALL-E를 능가하는 OpenAI의 GLIDE

Created: 2022년 6월 19일 오후 4:07
Last Edited Time: 2022년 7월 17일 오전 4:02
Status: 완료
요약:  OpenAI에서 공개한 GLIDE 찍먹해보기

- 이 글에서 관심을 갖게 됨.

[챗봇 딥러닝 - DALL-E를 능가하는 OpenAI의 GLIDE](http://aidev.co.kr/chatbotdeeplearning/11071)

- 깃헙 사이트는 여기고..

[https://github.com/openai/glide-text2im](https://github.com/openai/glide-text2im)

- Colab으로 제공해 줘서 카피 떠서 함 돌려봄
    - 프롬프트를 바꿀때 마다 속도는 대략 10초정도 걸림
    - 이것저것 해 봤는데… 별론데?